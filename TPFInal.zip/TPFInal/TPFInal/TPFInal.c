/*
 * Thingspeak.c
 *
 * Created: 29-01-2019 17:33:31
 *  Author: Kumar
 */ 


#define F_CPU 16000000									// Clock Frequency
#define BAUD_PRESCALE 8									//#Change UBRRL Value
#define ref 0x40
#include <avr/io.h>										// Basic I/O Functions
#include <util/delay.h>									// Delay Functions

void uart_init(){										// UART Initialization
	UCSRB |= (1 << RXEN)|(1 << TXEN);					// Enable Rx and Tx pins from UCSRB
	UCSRC |= (1 << URSEL)| (1 << UCSZ0) | (1 << UCSZ1);	// Enable 8-bit Character Size
	UBRRL = BAUD_PRESCALE;								// UBRRL Value
	//UBRRH = (BAUD_PRESCALE>> 8);						// UBRRH Value
}

void putch(char send){									// Character Send
	while(!(UCSRA & (1<<UDRE))){						// Wait While the conversion completes
	}
	UDR=send;											// Character Sent
}

unsigned int getch(){									// Receiving a Character
	while ((UCSRA & (1 << RXC)) == 0){					// Wait While Receiving Completes
	}
	return UDR;											// Character Received
}

void putstr(char*send){									// String Send
	int i=0;
	while(send[i]!='\0'){								// Initialize String
		while(!(UCSRA & (1<<UDRE)));					// Wait While Sending
		UDR=send[i];
		i++;
	};
}

void adc_init(void){        // Initialization of ADC
	ADMUX=(1<<REFS0);		//AREF 0
	ADCSRA = (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1); //#change
}

unsigned int adc_read(unsigned char adc_input){			// ADC Read
	ADMUX=adc_input|ref;								// Select ADC Pin
	_delay_us(9);										// Delay needed for the stabilization of the ADC input voltage
	ADCSRA|=0x48;										// Start the AD conversion
	while ((ADCSRA & 0x10)==0);							// Wait for the AD conversion to complete
	return ADCW;
}

int main(void){
	uart_init();										// Initialize UART
	adc_init();											// Initialize ADC
	int Val = 0;
	char Str[10];
	/*putstr("AT\r\n");								// Echo Off
	_delay_ms(1000);								//Connect your Wi-Fi first.
	putstr("AT+CWMODE=3\r\n");						//using AT command
	_delay_ms(1000);
	putstr("AT+CWJAP=\"Kumar\",\"123450001\"\r\n");		// Add Your SSID Password Here
	_delay_ms(5000);*/										// Wait for 3 Seconds
	putstr("AT+CIPMUX=1\r\n");
	_delay_ms(1000);
    while(1){											// Infinite Loop
		Val = adc_read(0);										// Read ADC Value From Sensor Connected at pin 0
		itoa(Val, Str, 10);										// Convert Interger to String
		putstr("AT+CIPSTART=4,\"TCP\",\"184.106.153.149\",80\r\n");	// Start TCP to Thingspeak Server
		_delay_ms(500);
		putstr("AT+CIPSEND=4,50\r\n");
		_delay_ms(100);								//
		putstr("GET /update?api_key=Your_API_Key&field1=");	// Replace Your API Key
		putstr(Str);
		putstr("\r\n");
		_delay_ms(1000);											// Sensor Value as String
		putstr("AT+CIPCLOSE=4\r\n");
		_delay_ms(15000);										//#
    }
}